arduvision
==========

embedded computer vision with arduino
http://therandomlab.blogspot.com.es/search/label/ov7670
